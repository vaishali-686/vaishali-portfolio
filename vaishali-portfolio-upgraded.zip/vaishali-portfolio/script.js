document.addEventListener('DOMContentLoaded', () => {
  const tabs = [...document.querySelectorAll('.nav-tab')];
  const panels = [...document.querySelectorAll('.panel')];
  const titles = {home:'Overview',about:'About me',skills:'Skills',projects:'Projects',certificates:'Certificates',contact:'Contact'};
  const sidebar = document.querySelector('.sidebar');
  const currentPage = document.getElementById('currentPage');
  document.getElementById('year').textContent = new Date().getFullYear();

  function showTab(id) {
    if (!titles[id]) return;
    tabs.forEach(button => button.classList.toggle('active', button.dataset.tab === id));
    panels.forEach(panel => panel.classList.toggle('active', panel.id === id));
    currentPage.textContent = titles[id];
    sidebar.classList.remove('open');
    history.replaceState(null, '', '#' + id);
  }
  tabs.forEach(button => button.addEventListener('click', () => showTab(button.dataset.tab)));
  document.querySelectorAll('[data-open]').forEach(button => button.addEventListener('click', () => showTab(button.dataset.open)));
  document.querySelector('.brand').addEventListener('click', event => { event.preventDefault(); showTab('home'); });
  document.getElementById('mobileMenu').addEventListener('click', () => sidebar.classList.toggle('open'));

  const filters = [...document.querySelectorAll('.filter')];
  const certificates = [...document.querySelectorAll('.certificate-item')];
  filters.forEach(filter => filter.addEventListener('click', () => {
    const category = filter.dataset.filter;
    filters.forEach(item => item.classList.toggle('active', item === filter));
    certificates.forEach(card => { card.hidden = category !== 'all' && card.dataset.category !== category; });
  }));

  const projects = {
    axora: {title:'AXORA', intro:'An AI-powered learning ecosystem concept designed to bring subject learning, learner support and accessible learning experiences into one platform.', problem:'Learners may need to move between separate tools for syllabus-based study, topic explanations, language support and practice. AXORA aims to organise these learning journeys in one place.', workflow:[['Learner input','A student selects a school or college learning path, or provides a syllabus, topic or question.'],['Content interpretation','The planned AI layer analyses the input and identifies the subject or concept that needs support.'],['Learning response','The platform is intended to provide structured explanations and learning resources in an accessible format.'],['Practice and feedback','Learners can continue with questions, revision and practice activities to reinforce understanding.']], stack:['React','JavaScript','AI integration (planned)','Education UX'], contribution:'Frontend and product experience design: learner-facing navigation, dashboard concepts and learning-mode experience. Clearly demonstrate which features are implemented in the current build versus planned.',},
    aquawiki: {title:'AquaWiki', intro:'A water-conservation knowledge website that organises practical techniques and community suggestions in one accessible place.', problem:'Useful water-saving information can be scattered across sources. AquaWiki is designed to help visitors learn conservation methods and contribute suggestions.', workflow:[['Visit the website','Users navigate Home, About, Techniques, Community and Contact sections.'],['Explore techniques','Visitors read water-conservation methods and practical information.'],['Submit a suggestion','The community area accepts suggestions through the application workflow.'],['Store and manage data','The Flask application uses SQLite for suggestion storage.'],['Review and improve','Stored suggestions can support community knowledge sharing and future improvements.']], stack:['Python','Flask','SQLite','HTML','CSS'], contribution:'Academic project focused on building a water-conservation knowledge platform, organising the pages and connecting the Flask application with SQLite suggestion storage.',},
    scriptsense: {title:'ScriptSense AI', intro:'A team project exploring intelligent handwritten answer evaluation using OCR and semantic analysis.', problem:'Evaluating handwritten answers can involve reading images or documents, comparing a response with expected content, and communicating useful feedback. ScriptSense AI explores how AI components could support parts of this workflow.', workflow:[['Upload an answer','A user provides a handwritten answer as an image or supported document.'],['Pre-process the input','Image-processing steps prepare the answer for text recognition.'],['Recognise handwriting','OCR tools such as TrOCR or EasyOCR are explored to extract text.'],['Compare meaning','Semantic-embedding methods can compare extracted text with reference answers.'],['Generate feedback','The planned evaluation flow combines marks, confidence and improvement feedback.'],['Create a report','The concept includes producing a report for the user to review.']], stack:['Python','OCR','OpenCV','NumPy','pandas','sentence-transformers','Gemini API (planned/used as applicable)'], contribution:'Team project. Describe your actual assigned AI-development tasks and the components you personally implemented during evaluation. Do not claim end-to-end functionality unless it has been built and tested.'}
  };
  const modal = document.getElementById('projectModal');
  const closeModal = () => { modal.classList.remove('open'); modal.setAttribute('aria-hidden','true'); document.body.style.overflow=''; };
  function openProject(key) {
    const data = projects[key]; if (!data) return;
    document.getElementById('detailTitle').textContent = data.title;
    document.getElementById('detailIntro').textContent = data.intro;
    document.getElementById('detailProblem').textContent = data.problem;
    document.getElementById('detailContribution').textContent = data.contribution;
    const workflow = document.getElementById('detailWorkflow'); workflow.replaceChildren();
    data.workflow.forEach((step,index) => { const item=document.createElement('div'); item.className='workflow-step'; const num=document.createElement('div'); num.className='workflow-step-num'; num.textContent=String(index+1).padStart(2,'0'); const copy=document.createElement('div'); const heading=document.createElement('h4'); heading.textContent=step[0]; const description=document.createElement('p'); description.textContent=step[1]; copy.append(heading,description); item.append(num,copy); workflow.append(item); });
    const stack = document.getElementById('detailStack'); stack.replaceChildren(); data.stack.forEach(label=>{const tag=document.createElement('span');tag.textContent=label;stack.append(tag);});
    modal.classList.add('open'); modal.setAttribute('aria-hidden','false'); document.body.style.overflow='hidden'; document.querySelector('.detail-close').focus();
  }
  document.querySelectorAll('[data-project]').forEach(card => { card.addEventListener('click',()=>openProject(card.dataset.project)); card.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();openProject(card.dataset.project);}}); });
  modal.querySelectorAll('[data-close-project]').forEach(el=>el.addEventListener('click',closeModal));
  document.addEventListener('keydown',event=>{if(event.key==='Escape'&&modal.classList.contains('open'))closeModal();});

  const initial = location.hash.slice(1);
  if (titles[initial]) showTab(initial);
});

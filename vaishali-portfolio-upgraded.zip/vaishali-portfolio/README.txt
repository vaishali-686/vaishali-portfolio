VAISHALI RAJAN — PORTFOLIO

RUN LOCALLY
1. Extract this ZIP.
2. Open the vaishali-portfolio folder in Visual Studio Code.
3. Open index.html with the Live Server extension, or open index.html in a browser.
4. Keep images/ and certificates/ beside index.html. Do not move the files out of their folders.

FILES
- index.html: portfolio content, navigation, project cards, certificate links and contact links
- style.css: visual design and responsive layout
- script.js: tab navigation, certificate filters and project detail workflows
- images/: profile images
- certificates/: original certificate files linked from the Certificates tab

CONTACT LINKS ALREADY CONFIGURED
LinkedIn: https://www.linkedin.com/in/vaishali-rajan-it686
GitHub: https://github.com/vaishali-686
Email: vaishalirajan686@gmail.com

PROJECT DETAILS
Click a project card to open its detailed workflow. Review every description and change it if it does not match the features actually implemented. The detail view explicitly distinguishes intended/planned components from confirmed project foundations; only claim what you can demonstrate during evaluation.

PUBLISHING
For a static host such as GitHub Pages, upload the contents of this folder while preserving the relative folder structure. Test certificate links and all contact links after publishing.
